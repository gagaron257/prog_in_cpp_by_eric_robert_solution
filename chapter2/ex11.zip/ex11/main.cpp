/*
 * File : main.cpp
 * -------------------------------------------
 * Using the direction.h interface as an example, design and implement a
 * calendar.h interface that exports the Month type from Chapter 1, along with
 * the functions daysInMonth and isLeapYear , which also appear in that
 * chapter. Your interface should also export a monthToString function that
 * returns the constant name for a value of type Month . Test your implementation
 * by writing a main program that asks the user to enter a year and then writes out
 * the number of days in each month of that year, as in the following sample run:
 * TestCalendar
 * Enter a year: 2012
 * JANUARY has 31 days.
 * FEBRUARY has 29 days.
 * MARCH has 31 days.
 * APRIL has 30 days.
 * MAY has 31 days.
 * JUNE has 30 days.
 * JULY has 31 days.
 * AUGUST has 31 days.
 * SEPTEMBER has 30 days.
 * OCTOBER has 31 days.
 * NOVEMBER has 30 days.
 * DECEMBER has 31 days.
 */

#include <iostream>
#include "calendar.h"
using namespace std;

int main()
{
  cout <<"Enter the year : ";
  int year;
  cin >> year;
  print_month_days_chart(year);
  
  return 0;
}
