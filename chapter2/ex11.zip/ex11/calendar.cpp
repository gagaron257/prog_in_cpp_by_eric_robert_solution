/*
 * File: calendar.cpp
 * -------------------
 * This file implements the calendar.h interface.
 */

#include "calendar.h"
#include <string>
#include <iostream>
using namespace std;

string month_to_string(Month month)
{
  switch(month)
  {
    case JANUARY  : return "JANUARY";
    case FEBUARY  : return "FEBUARY";
    case MARCH    : return "MARCH";
    case APRIL    : return "APRIL";
    case MAY      : return "MAY";
    case JUNE     : return "JUNE";
    case JULY     : return "JULY";
    case AUGUST   : return "AUGUST";
    case SEPTEMBER: return "SEPTEMBER";
    case OCTOBER  : return "OCTOBER";
    case NOVEMBER : return "NOVEMBER";
    case DECEMBER : return "DECEMBER";
    default: return "???";
  }
}

int days_in_month(Month month, int year)
{
  int days{0};

  switch(month)
  {
    case JANUARY  : 
    case MARCH    : 
    case MAY      : 
    case JULY     : 
    case AUGUST   : 
    case OCTOBER  : 
    case DECEMBER : 
      days = 31;
      break;
    case APRIL    : 
    case JUNE     : 
    case SEPTEMBER: 
    case NOVEMBER : 
      days = 30;
      break;
    case FEBUARY :
      days = (is_leap_year(year) ? 29 : 28);
      break; 
    default:
      days = 0;
  }
    return days;
}

bool is_leap_year(int year) 
{
  return ((year % 4 == 0) && (year % 100 != 0))
    || (year % 400 == 0);
}       

void print_month_days_chart(int year)
{
  for (int i = 1; i <= 12; i++)
  {
    cout << month_to_string(Month(i)) << " has " << days_in_month(Month(i), year) << endl;
  }
}
