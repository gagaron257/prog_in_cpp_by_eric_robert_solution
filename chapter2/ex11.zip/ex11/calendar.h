/*
* File: calendar.h
* -------------
* This interface export an enumerated type  called Month whose elements 
* are 12 months of the year.
*/

#ifndef _CALENDAR__H
#define _CALENDAR__H

#include <string>

/*
 * Type: Month
 * ---------------
 * This enumerated type is used to represent the 12 months of year.
 */
enum Month {
  JANUARY = 1,
  FEBUARY,
  MARCH,
  APRIL,
  MAY,
  JUNE,
  JULY,
  AUGUST,
  SEPTEMBER,
  OCTOBER,
  NOVEMBER,
  DECEMBER
};

/*
 * Function: days_in_month
 * Usage: int days = days_in_month(month, year);
 * ----------------------------------------
 * The function returns the number of days in
 * the month passed as argument.
 */
int days_in_month(Month month, int year);

/*
 * Function: is_leap_year
 * Usage: bool isleap = is_leap_year(year);
 * ----------------------------------------
 * This predicate function returns the value true
 * if year is leap year , otherwise false.
 */
bool is_leap_year(int year);

/*
 * Function: month_to_string
 * Usage: std::string s = month_to_string(month);
 * ----------------------------------------
 * Returns the string representation of the month.
 */
std::string month_to_string(Month month);

/*
 * Function: print_month_days_chart
 * Usage: print_month_days_chart(year);
 * ----------------------------------------
 * This function prints the month and days chart of year.
 */

void print_month_days_chart(int year);

#endif
