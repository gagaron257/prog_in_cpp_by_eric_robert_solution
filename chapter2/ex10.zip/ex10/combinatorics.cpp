/*
 * File: combinatorics.cpp
 * ---------------
 * This file implements the combinatorics.h interface. 
 * The efficent memory handling has been done by not using 
 * factorial function call.
 */

#include "combinatorics.h"

int permutations(int n, int k)
{
  int val{1};
  
  for(int i = (n-k) + 1; i <= n; i++)
    val = val * i;                                                                                                                                            

  return val;
}

int combinations(int n, int k)
{
  int temp = permutations(n, k);
  for (int i = 2; i <= k; i++)
    temp = temp / i;

  return temp;
}
