/*
* File: combinatorics.h
* -------------
* The file declares the two api of permutation and combinations.
*/

#ifndef _COMBINATORICS__H
#define _COMBINATORICS__H

/*
 * Function: permutations
 * Usage: int p = permutations(n, k)
 * -------------------------------------
 * Returns the P(n, k) function
 * without calling the fact function.
 */
int permutations(int n, int k);

/*
 * Function: combinations
 * Usage: int p = combinations(n, k)
 * -------------------------------------
 * Returns the C(n, k) function
 * without calling the fact function.
 */
int combinations(int n, int k);

#endif
